//
//  JeneratorSDK.h
//  JeneratorSDK
//
//  Created by XcodeBuildServer on 04/06/16.
//  Copyright © 2016 menke-dev. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for JeneratorSDK.
FOUNDATION_EXPORT double JeneratorSDKVersionNumber;

//! Project version string for JeneratorSDK.
FOUNDATION_EXPORT const unsigned char JeneratorSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JeneratorSDK/PublicHeader.h>


